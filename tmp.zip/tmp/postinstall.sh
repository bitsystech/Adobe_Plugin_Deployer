#!/bin/sh
## postinstall

pathToScript=$0
pathToPackage=$1
targetLocation=$2
targetVolume=$3
CD="/usr/local/HMUtils/CocoaDialog.app/Contents/MacOS/CocoaDialog"
EMC="/private/tmp/C3/Contents/MacOS/ExManCmd"


# Fx the following line to make it better. However it works.
osascript /private/tmp/C3/ID_Quitter.scpt
# This will detect if InDesign is running and will quit. 

sleep 5
$EMC --install "/private/tmp/C3/Contents/MacOS/AppStudioExporter_2_3_1.zxp"  > /dev/null 2>&1
sleep 5

$CD bubble --debug --title "C3 Plugin v2.0.6" --text "C3 Plugin installation was successful. Please start using now." \
	--background-top "e0e0e0" --background-bottom "f8f8f8" \
	--icon "info"

touch ~/Desktop/testingshfile.txt

exit 0		## Success
exit 1		## Failure
